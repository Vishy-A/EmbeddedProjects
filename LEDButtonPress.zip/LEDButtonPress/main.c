//https://youtu.be/oTDlpA-lvko
// ^ video ^




#include <msp430.h>
#include <stdint.h>
#include <stdbool.h>

void initGPIO(){
    P1DIR = BIT0;
    P1OUT &= ~BIT0;

    P4DIR |= BIT0;
    P4REN |= BIT1;
    P4OUT |= BIT1;

    P6DIR = BIT6;
    P6OUT &= ~BIT0;

}

void init(){
    WDTCTL = WDTPW | WDTHOLD;
    PM5CTL0 &= ~LOCKLPM5;

    initGPIO();
}

bool buttonPress(){
    return (P4IN & BIT1) == 0x00;
}

void setRedLED(bool enable){
    if(enable){
        P1OUT |= BIT0;
    }
    else {
        P1OUT &= ~BIT0;
    }
}

void setGreenLED(bool enable){
    if(enable){
        P6OUT |= BIT6;
    }
    else {
        P6OUT &= ~BIT6;
    }
}

int main(void){
    init();
    bool press;
    int count = 1;
    while(1){
        if(count > 3){
            count = 1;
        }
        if(buttonPress()){
            if(press == false){
                __delay_cycles(1000000);
                if(buttonPress()){
                    press = true;
                    count++;
                }
                else{
                press = false;
                }
            }
        }
        else{
            press = false;
        }
        if(count == 1){
            setGreenLED(false);
            setRedLED(true);
        }
        else if(count == 2){
                setGreenLED(true);
                setRedLED(false);
        }
        else if(count == 3){
            setGreenLED(true);
            setRedLED(true);
        }

     }


}

