#include <msp430.h>
#include <stdint.h>
#include <stdbool.h>
#include "Four_Digit_Display.h"


typedef enum{ PAUSE, MOVING } movement_t;
typedef enum{ FORWARD, REVERSE } direction_t;
typedef struct{
    bool sw1Pressed;
    bool sw2Pressed;
    int8_t position;
    direction_t direction;
} input_t;

void initGpio(){

P1OUT = BIT1;
P1DIR = BIT0;
P6DIR |= BIT6;

// SW2
P2DIR &= ~BIT3;
P2OUT |= BIT3;
P2REN |= BIT3;
P2IES = BIT3;
P2IFG = 0;
P2IE = BIT3;

// SW1
P4DIR &= ~BIT1;
P4OUT |= BIT1;
P4REN |= BIT1;
P4IES = BIT1;
P4IFG = 0;
P4IE = BIT1;
}

void setRedLed(bool enable){
    if(enable){
        P1OUT |= BIT0;
    } else {
        P1OUT &= ~BIT0;
    }
}
void setGreenLed(bool enable){
    if(enable){
        P6OUT |= BIT6;
    } else {
        P6OUT &= ~BIT6;
    }
}
void delay(){
    __delay_cycles(1000000);
}
void drawTrain(unsigned int pos){
    four_digit_clear();
    switch(pos){
    case 0:
        display_segment(POS_1, SEG_D);
        display_segment(POS_2, SEG_D);
        display_segment(POS_3, SEG_D);
    break;
    case 1:
        display_segment(POS_1, SEG_D | SEG_E);
        display_segment(POS_2, SEG_D);
    break;
    case 2:
        display_segment(POS_1, SEG_D | SEG_E | SEG_F);
    break;
    case 3:
        display_segment(POS_1, SEG_A | SEG_E | SEG_F);
    break;
    case 4:
        display_segment(POS_1, SEG_A | SEG_F);
        display_segment(POS_2, SEG_A);
    break;
    case 5:
        display_segment(POS_1, SEG_A);
        display_segment(POS_2, SEG_A);
        display_segment(POS_3, SEG_A);
    break;
    case 6:
        display_segment(POS_2, SEG_A);
        display_segment(POS_3, SEG_A);
        display_segment(POS_4, SEG_A);
    break;
    case 7:
        display_segment(POS_3, SEG_A);
        display_segment(POS_4, SEG_A | SEG_B);
    break;
    case 8:
        display_segment(POS_4, SEG_A | SEG_B | SEG_C);
    break;
    case 9:
        display_segment(POS_4, SEG_B | SEG_C | SEG_D);
    break;
    case 10:
        display_segment(POS_4, SEG_C | SEG_D);
        display_segment(POS_3, SEG_D);
    break;
    case 11:
        display_segment(POS_4, SEG_D);
        display_segment(POS_3, SEG_D);
        display_segment(POS_2, SEG_D);
    break;
    default:
    break;
}
}
movement_t pauseState(input_t* inputs){
    setRedLed(true);
    setGreenLed(false);
    // next state
    if(inputs->sw1Pressed){
        inputs->sw1Pressed = false;
    return MOVING;
    }
    return PAUSE;
}
movement_t movingState(input_t* inputs){
    setGreenLed(true);
    setRedLed(false);
    if(inputs->sw2Pressed){
        if(inputs->direction == FORWARD)
            inputs->direction = REVERSE;
        else
            inputs->direction = FORWARD;
            inputs->sw2Pressed = false;
    }
    if(inputs->direction == FORWARD){
        inputs->position++;
    if(inputs->position > 11)
        inputs->position = 0;
    } else {
        inputs->position--;
        if(inputs->position < 0)
            inputs->position = 11;
    }
    drawTrain(inputs->position);
    delay();
      // next state
      if(inputs->sw1Pressed){
         inputs->sw1Pressed = false;
      return PAUSE;
      }
    return MOVING;
}
input_t inputs;
int main(void){
    WDTCTL = WDTPW | WDTHOLD;
    PM5CTL0 &= ~LOCKLPM5;
    // initialize button inputs
    inputs.sw1Pressed = false;
    inputs.sw2Pressed = false;
    inputs.position = 0;
    inputs.direction = FORWARD;
    movement_t state = MOVING;
    initGpio();
    four_digit_init();
    __enable_interrupt();
    while(1){
        switch(state){
            case MOVING:
            state = movingState(&inputs);
            break;
            case PAUSE:
            state = pauseState(&inputs);
            break;
            default:
            state = PAUSE;
            break;
        }
    }
}
// port 1 interrupt
#pragma vector=PORT2_VECTOR
__interrupt void Port_2(void)
{
    __no_operation();
    if(P2IFG & BIT3){ // sw2 interrupt
        inputs.sw2Pressed = true;
        P2IFG &= ~BIT3;
    }
}
// port 4 interrupt
#pragma vector=PORT4_VECTOR
__interrupt void Port_4(void)
{
    if(P4IFG & BIT1){ // sw2 interrupt
        inputs.sw1Pressed = true;
        P4IFG &= ~BIT1;
    }
}
