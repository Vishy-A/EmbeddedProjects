//Vishy Adusumilli
//Lab 4 Ultrasonic Alarm
//https://youtu.be/GQnMm3tukfk


#include <msp430.h>
#include <stdbool.h>
#include <stdint.h>

void initGpio();
void init();

bool SW1Press();
void setRedLed(bool enable);
void setGreenLed(bool enable);
void setbuzzer(bool enable);
float getDistance();

typedef enum{INIT, ARM, ALARM, MAX_STATES} state_t;
state_t initState();
state_t armedState();
state_t alarmState();
state_t (*state_table[MAX_STATES])(uint16_t) = {initState, armedState, alarmState};
float ultrasonicDist;
float armedDist;
volatile uint16_t count = 0.0;
bool buttonPressed;

int main(void){
    init();

    state_t currentState = INIT;
    state_t nextState = currentState;

    while(1){
        ultrasonicDist = getDistance();
        buttonPressed = SW1Press();
        switch(currentState){

            case INIT:
                nextState = initState();
                break;
            case ARM:
                nextState = armedState();
                break;
            case ALARM:
                nextState = alarmState();
                break;
            default:
                break;
        }
        currentState = nextState;
    }
}

state_t initState(){
    setbuzzer(false);
    setRedLed(false);
    setGreenLed(true);
    if(buttonPressed){
        buttonPressed = false;
        armedDist = ultrasonicDist;
        return ARM;
    }
    return INIT;
}

state_t armedState(){
    setRedLed(true);
    setGreenLed(false);
    setbuzzer(false);
    if(abs(armedDist - ultrasonicDist) > .01){
        return ALARM;
    } else{
        return ARM;
    }
}

state_t alarmState(){
    setRedLed(true);
    setGreenLed(true);
    setbuzzer(true);
    if(buttonPressed){
        buttonPressed = false;
        armedDist = ultrasonicDist;
        return INIT;
    } else{
        return ALARM;
    }
}

void initGpio(){
    // Red LED
    P1DIR |= BIT0;
    // Button
    P4DIR &= ~BIT1;
    P4REN |= BIT1;
    P4OUT |= BIT1;
    // Green LED
    P6DIR |= BIT6;
    // Buzzer
    P6DIR |= BIT3;
}

void init(){
    WDTCTL = WDTPW | WDTHOLD;
    PM5CTL0 &= ~LOCKLPM5;
    initGpio();
}

void setbuzzer(bool enable){
    if(enable == true){
        P6OUT |= BIT3;
    } else {
        P6OUT &= ~BIT3;
    }
}

void setRedLed(bool enable){
    if(enable){
        P1OUT |= BIT0;
    } else {
        P1OUT &= ~BIT0;
    }
}

void setGreenLed(bool enable){
    if(enable){
        P6OUT |= BIT6;
    } else {
        P6OUT &= ~BIT6;
    }
}

bool SW1Press(){
    if((P4IN & BIT1) == 0x00){
            // debounce
            __delay_cycles(1000);
            if((P2IN & BIT3) == 0x00){
                return true;
            }
        }

        return false;
}

float getDistance(){
      P5DIR &= ~BIT4;
      P5OUT &= ~BIT4;
      TB1R=0;
      P5DIR |= BIT4;
      P5OUT |= BIT4;
      __delay_cycles(10);
      P5OUT &= ~BIT4;
      P5DIR &= ~BIT4;

      while((P5IN & BIT4) == 0x00);

      TB1CTL = TBSSEL__SMCLK | MC__CONTINUOUS;
      while(P5IN & BIT4);
      TB1CTL = TBSSEL__SMCLK | MC__STOP;
      count=TB1R;

      float dist = (count*0.000001*343)/2;

      TB1CTL = TBCLR;
      return dist;
}
