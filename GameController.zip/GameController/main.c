#include <msp430.h>
#include <stdbool.h>
#include <stdint.h>

void initClocks();
void initGPIO();
void initUART1();
void initADC();
float readADC();
void writeUART(int d);
bool S1Press;
bool S2Press;
float ADC;

void initClocks(){
// Set XT1CLK as ACLK source
CSCTL4 |= SELA__XT1CLK;
// Use external clock in low-frequency mode
CSCTL6 |= XT1BYPASS_1 | XTS_0;
}

void initUART1(){
// Configure UART pins
P4SEL0 |= BIT3 | BIT2; // set 2-UART pin as second function
P4SEL1 &= ~(BIT3 | BIT2);
// Configure UART
UCA1CTLW0 = UCSWRST; // Hold UART in reset state
UCA1CTLW0 |= UCSSEL__ACLK; // CLK = ACLK
// Baud Rate calculation
// 32768/(9600) = 3.4133
// Fractional portion = 0.4133
// User's Guide Table 17-4: 0x92
UCA1BR0 = 3; // 32768/9600
UCA1BR1 = 0;
UCA1MCTLW |= 0x9200; //0x9200 is UCBRSx = 0x92
UCA1CTLW0 &= ~UCSWRST; // Release reset state for operation
UCA1IE |= UCRXIE; // Enable USCI_A0 RX interrupt
}

int main(void)
{
WDTCTL = WDTPW | WDTHOLD; // Stop watchdog timer
PM5CTL0 &= ~LOCKLPM5;
initClocks();
initUART1();
initGPIO();
initADC();
__enable_interrupt();
while(1){
    __delay_cycles(10000);
    ADC = readADC();
    if(S1Press || S2Press){
        writeUART(255);

        S1Press = false;
        S2Press = false;
    }
    if(ADC != 255){
        writeUART(ADC);
    }
}
}

void initGPIO(){
    P4DIR |= BIT0;
    P4REN |= BIT1;
    P4OUT |= BIT1;
    P4IES |= BIT1;
    P4IE |= BIT1;

    P2DIR |= BIT0;
    P2REN |= BIT3;
    P2OUT |= BIT3;
    P2IES |= BIT3;
    P2IE |= BIT3;

    P1OUT &= ~BIT0;
    P1DIR = BIT0;
    P6OUT &= ~BIT0;
    P6DIR = BIT6;
}

void initADC(){
    P5SEL0 |= BIT3;
    P5SEL1 |= BIT3;

    ADCCTL0 |= ADCSHT_1 | ADCON;
    ADCCTL1 |= ADCSHP | ADCSSEL_3;
    ADCCTL2 &= ~ADCRES;
    ADCCTL2 |= ADCRES_0;
    ADCMCTL0 |= ADCINCH_11 | ADCSREF_0;
}

float readADC(){
    ADCCTL0 |= ADCENC | ADCSC;
    while(ADCCTL1 & ADCBUSY);
    float ADCVal = ADCMEM0;
    return ADCVal;
}

void writeUART(int d){
    while(!(UCA1IFG & UCTXIFG));
    UCA1TXBUF = d;
}



#pragma vector=PORT2_VECTOR // right interrupt
__interrupt void Port2ISR(void){
    S2Press = true;
    P2IFG &= ~BIT3;
}

#pragma vector=PORT4_VECTOR // left interrupt
__interrupt void Port4ISR(void){
    S1Press = true;
    P4IFG &= ~BIT1;
}
#pragma vector=USCI_A1_VECTOR
__interrupt void USCI_A1_ISR(void)
{
UCA1TXBUF = UCA1RXBUF;
__no_operation();
// Clear flag
UCA1IFG = 0;
}
